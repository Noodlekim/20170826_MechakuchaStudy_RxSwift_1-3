//
//  ViewController.swift
//  RxKim
//
//  Created by GiBong Kim on 2017. 8. 26..
//  Copyright © 2017년 GiBong Kim. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController {

    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    let bag = DisposeBag()
    let viewModel: ViewModelType = ViewModel()
    
    var tableItems = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // VCはbindViewModel()で購読準備完了！
        bindViewModel()
    }
    
    func bindViewModel() {

        // Protocolを利用してinnput/ outputのみ参照できるようにしました。
        // VCは全ての処理を単独でしないでViewModel経由でします。
        
        // 1. ボタンがタップされました。
        button.rx.controlEvent(UIControlEvents.touchUpInside).asObservable()
            .subscribe(onNext: { (_) in
                self.viewModel.input.buttonAction()
            })
            .addDisposableTo(bag)
        
        // 2. データを受け取ってテーブルビューを更新
        viewModel.output.items.asObservable()
            .subscribeOn(MainScheduler.instance)
            .subscribe(onNext: { (items) in
                self.tableItems = items
                self.tableView.reloadData()
            })
            .addDisposableTo(bag)
    }
}


// MARK: - UITableViewDelegate, DataSource

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.tableItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        
        // デフォルトセルを生成
        let cell = UITableViewCell.init(style: .default, reuseIdentifier: "rxCell")
        
        // 各Itemを取得
        let item = tableItems[indexPath.row]

        // 画像設定
        do {
            let data = try Data.init(contentsOf: URL.init(string: item.imageURL)!)
            cell.imageView?.image = UIImage.init(data: data)
        } catch {
            
        }
        // テキスト設定
        cell.textLabel?.text = item.title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 60
    }

}


