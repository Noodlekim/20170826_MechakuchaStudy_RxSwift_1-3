//: Playground - noun: a place where people can play

import UIKit
import RxSwift

/*
 - RxSwiftインストール😶
 - Observableを生成してみる😯
 - 購読(Subscribe)をしてみる😲
 - Disposeをしてみる😲
 - 他の形のObservableを知っておく😳
 - RxCocoaを使ってみよう！🤓
 - MVVMで簡単に実装してみる🤗
    - ViewController.swiftとViewModel.swift参照してください。
 */


// 1. RxSwiftはObservableとSubscribeで動く
// 　なのでこの二つの概念で処理することを念頭することが一番大事！
Observable.of(1,2,3,4,5)
    .subscribe { (event) in
        print("event > \(event)")
    }
    // subscribeが終わってもう購読しない場合は dispose()をして解除をする
    .dispose()


// テスト用エラー
enum KimError: Error {
    case error1
    case error2
}

// 3. Observableの生成方法２
// 非同期でonNext, onError処理をしたい場合
// onErrorの場合はそのままonCompletedになるので注意
let observer = Observable<String>.create { (observer) -> Disposable in

    // 1) リクエストでデータを取得
    // 2) Model化してoKだったらonNextで渡す
    // 3) NGだったらonErrorで通知する
    observer.onNext("gaku")
    observer.onNext("kimu")
    // 注意：Errorが発生したら自動的にonCompletedになるのでそれからonNextイベントが効かない
    // 　　これはobserver.onCompleted()をした時も同じ
    observer.onError(KimError.error1)
    
    return Disposables.create()
}

// 2. DisposeBagはあるObjectが解除されるタイミングで一緒に購読を解除したい場合する
let bag = DisposeBag()

// 2.1 こんな感じで使う
observer
    .subscribe { (event) in
        print("event2 > \(event)")
    }
    .addDisposableTo(bag)


// 3. PublishSubjectでonNext, onErrorができる
let subject = PublishSubject<String>()
// これは先subscribeをしなければいけない
subject
    .subscribe { (event) in
        print("event3 > \(event)")
}

subject.on(Event.next("test2222"))

// 4.Single.create
// 一回イベント発生したらそのまま終わらせたい場合
// Observableと違ってonNextを複数投げても最初一回だけ反映される
let single = Single<Int>.create { (observer) -> Disposable in

    observer(SingleEvent.success(100))
    observer(SingleEvent.success(200))

    observer(SingleEvent.error(KimError.error2))
    
    return Disposables.create()
}

single
    .subscribe(onSuccess: { (value) in
        print("value \(value)")
    }) { (error) in
        print("errpr \(error)")
    }




